

# =====================================
# 🔹 1. Bloques estáticos del modelo
# =====================================

XML_HEADER = r"""
<mujoco model="quadrotorplus">
    <compiler angle="degree" inertiafromgeom="true" coordinate="local"/>
    <option	timestep="0.01" gravity="0 0 -9.81" density="1" viscosity="1e-5" integrator="RK4"/>

    <default>
        <joint armature="1" damping="1" limited="true"/>
        <geom conaffinity="0" condim="3" density="5.0" friction="1 0.5 0.5" margin="0.01" rgba="0.8 0.6 0.4 1"/>
    </default>

    <asset>
        <texture builtin="gradient" type="skybox" height="100" width="100" rgb1="1 1 1" rgb2="0 0 0"/>
        <texture name="texgeom" builtin="flat" height="1278" mark="cross" markrgb="1 1 1" random="0.01" rgb1="0.8 0.6 0.4" rgb2="0.8 0.6 0.4" type="cube" width="127"/>
        <texture name="texplane" builtin="checker" height="100" width="100" rgb1="0 0 0" rgb2="0.8 0.8 0.8" type="2d"/>
        <material name="MatPlane" reflectance="0.5" shininess="1" specular="1" texrepeat="60 60" texture="texplane"/>
        <material name="geom" texture="texgeom" texuniform="true"/>
    </asset>

    <worldbody>
        <light cutoff="100" diffuse="1 1 1" dir="-0 0 -1.3" directional="true" exponent="1" pos="0 0 1.3" specular=".1 .1 .1"/>
        <geom conaffinity="1" condim="3" material="MatPlane" name="floor" pos="0 0 0" rgba="0.4 0.3 0.3 1" size="5 5 0.2" type="plane"/>
"""

XML_DRONES = r"""
        <!-- FIRST QUADROTOR -->
        <body name="core_1" pos="-0.5 0 0.2">
            <geom name="core_geom_1" type="box" pos="0 0 0" quat="1 0 0 0" size=".04 .04 .02" rgba=".8 .2 0 1" mass=".1"/>
            <joint name="root_1" type="free" damping="0" armature="0" pos="0 0 0" limited="false"/>
            <!-- brazos y motores -->
            <geom name="arm_front0_1" type="box" pos=".08 0 0" size=".04 .005 .005" quat="1 0 0 0" rgba=".8 .8 .8 1" mass=".02"/>
            <geom name="arm_back0_1" type="box" pos="-.08 0 0" size=".04 .005 .005" quat="0 0 0 1" rgba=".8 .8 .8 1" mass=".02"/>
            <geom name="arm_left0_1" type="box" pos="0 .08 0" size=".04 .005 .005" quat=".707 0 0 .707" rgba=".8 .8 .8 1" mass=".02"/>
            <geom name="arm_right0_1" type="box" pos="0 -.08 0" size=".04 .005 .005" quat=".707 0 0 -.707" rgba=".8 .8 .8 1" mass=".02"/>

            <body name="arm_front1_1" pos=".12 0 0">
                <geom type="box" pos=".01 0 .005" size=".01 .005 .01" quat="1 0 0 0" rgba="1 .1 0 1" mass=".02"/>
                <body name="thruster0_1" pos="0.01 0 0.015">
                    <geom type="cylinder" pos="0 0 .0025" size=".05 .0025" quat="1 0 0 0" rgba=".3 1 .3 0.3" mass=".005"/>
                    <site name="motor0_1" type="cylinder" pos="0 0 .0025" size=".01 .0025" quat="1 0 0 0" rgba=".3 1 .3 0.3"/>
                </body>
            </body>

            <body name="arm_back1_1" pos="-.12 0 0">
                <geom type="box" pos="-.01 0 .005" size=".01 .005 .01" quat="0 0 0 1" rgba="1 .1 0 1" mass=".02"/>
                <body name="thruster1_1" pos="-0.01 0 .015">
                    <geom type="cylinder" pos="0 0 .0025" size=".05 .0025" quat="1 0 0 0" rgba=".3 1 .3 0.3" mass=".005"/>
                    <site name="motor1_1" type="cylinder" pos="0 0 .0025" size=".01 .0025" quat="1 0 0 0" rgba=".3 1 .3 0.3"/>
                </body>
            </body>

            <body name="arm_left1_1" pos="0 .12 0">
                <geom type="box" pos="0 .01 .005" size=".01 .005 .01" quat=".7071068 0 0 .7071068" rgba="1 .1 0 1" mass=".02"/>
                <body name="thruster2_1" pos="0 0.01 0.015">
                    <geom type="cylinder" pos="0 0 .0025" size=".05 .0025" quat="1 0 0 0" rgba=".3 1 .3 0.3" mass=".005"/>
                    <site name="motor2_1" type="cylinder" pos="0 0 .0025" size=".01 0.0025" quat="1 0 0 0" rgba=".3 1 .3 0.3"/>
                </body>
            </body>

            <body name="arm_right1_1" pos="0 -.12 0">
                <geom type="box" pos="0 -.01 .005" size=".01 .005 .01" quat=".7071068 0 0 -.7071068" rgba="1 .1 0 1" mass=".02"/>
                <body name="thruster3_1" pos="0 -0.01 .015">
                    <geom type="cylinder" pos="0 0 .0025" size=".05 .0025" quat="1 0 0 0" rgba=".3 1 .3 0.3" mass=".005"/>
                    <site type="cylinder" pos="0 0 .0025" size=".01 .0025" quat="1 0 0 0" rgba=".3 1 .3 0.3" name="motor3_1"/>
                </body>
            </body>

            <site name="x_axis_1" type="box" pos=".1 .0 .0" size=".15 .005 .005" quat="1 0 0 0" rgba="1 0 0 0.2"/>
            <site name="y_axis_1" type="box" pos=".0 .1 .0" size=".15 .005 .005" quat=".707 0 0 .707" rgba="0 1 0 0.2"/>
            <site name="z_axis_1" type="box" pos=".0 .0 .1" size=".15 .005 .005" quat="-.707 0 .707 0" rgba="0 0 1 0.2"/>

            <site name="attach_left" pos="0 0 -0.03"/>
        </body>
        
        <!-- SECOND QUADROTOR -->
        <body name="core_2" pos="0.5 0 0.2">
            <geom name="core_geom_2" type="box" pos="0 0 0" quat="1 0 0 0" size=".04 .04 .02" rgba="0 0.2 0.8 1" mass=".1"/>
            <joint name="root_2" type="free" damping="0" armature="0" pos="0 0 0" limited="false"/>
            <geom name="arm_front0_2" type="box" pos=".08 0 0" size=".04 .005 .005" quat="1 0 0 0" rgba=".8 .8 .8 1" mass=".02"/>
            <geom name="arm_back0_2" type="box" pos="-.08 0 0" size=".04 .005 .005" quat="0 0 0 1" rgba=".8 .8 .8 1" mass=".02"/>
            <geom name="arm_left0_2" type="box" pos="0 .08 0" size=".04 .005 .005" quat=".707 0 0 .707" rgba=".8 .8 .8 1" mass=".02"/>
            <geom name="arm_right0_2" type="box" pos="0 -.08 0" size=".04 .005 .005" quat=".707 0 0 -.707" rgba=".8 .8 .8 1" mass=".02"/>

            <body name="arm_front1_2" pos=".12 0 0">
                <geom type="box" pos=".01 0 .005" size=".01 .005 .01" quat="1 0 0 0" rgba="1 .1 0 1" mass=".02"/>
                <body name="thruster0_2" pos="0.01 0 0.015">
                    <geom type="cylinder" pos="0 0 .0025" size=".05 .0025" quat="1 0 0 0" rgba=".3 1 .3 0.3" mass=".005"/>
                    <site name="motor0_2" type="cylinder" pos="0 0 .0025" size=".01 .0025" quat="1 0 0 0" rgba=".3 .3 1 0.3"/>
                </body>
            </body>

            <body name="arm_back1_2" pos="-.12 0 0">
                <geom type="box" pos="-.01 0 .005" size=".01 .005 .01" quat="0 0 0 1" rgba="1 .1 0 1" mass=".02"/>
                <body name="thruster1_2" pos="-0.01 0 .015">
                    <geom type="cylinder" pos="0 0 .0025" size=".05 .0025" quat="1 0 0 0" rgba=".3 1 .3 0.3" mass=".005"/>
                    <site name="motor1_2" type="cylinder" pos="0 0 .0025" size=".01 .0025" quat="1 0 0 0" rgba=".3 .3 1 0.3"/>
                </body>
            </body>

            <body name="arm_left1_2" pos="0 .12 0">
                <geom type="box" pos="0 .01 .005" size=".01 .005 .01" quat=".7071068 0 0 .7071068" rgba="1 .1 0 1" mass=".02"/>
                <body name="thruster2_2" pos="0 0.01 0.015">
                    <geom type="cylinder" pos="0 0 .0025" size=".05 .0025" quat="1 0 0 0" rgba=".3 1 .3 0.3" mass=".005"/>
                    <site name="motor2_2" type="cylinder" pos="0 0 .0025" size=".01 0.0025" quat="1 0 0 0" rgba=".3 .3 1 0.3"/>
                </body>
            </body>

            <body name="arm_right1_2" pos="0 -.12 0">
                <geom type="box" pos="0 -.01 .005" size=".01 .005 .01" quat=".7071068 0 0 -.7071068" rgba="1 .1 0 1" mass=".02"/>
                <body name="thruster3_2" pos="0 -0.01 .015">
                    <geom type="cylinder" pos="0 0 .0025" size=".05 .0025" quat="1 0 0 0" rgba=".3 1 .3 0.3" mass=".005"/>
                    <site type="cylinder" pos="0 0 .0025" size=".01 .0025" quat="1 0 0 0" rgba=".3 .3 1 0.3" name="motor3_2"/>
                </body>
            </body>

            <site name="x_axis_2" type="box" pos=".1 .0 .0" size=".15 .005 .005" quat="1 0 0 0" rgba="1 0 0 0.2"/>
            <site name="y_axis_2" type="box" pos=".0 .1 .0" size=".15 .005 .005" quat=".707 0 0 .707" rgba="0 1 0 0.2"/>
            <site name="z_axis_2" type="box" pos=".0 .0 .1" size=".15 .005 .005" quat="-.707 0 .707 0" rgba="0 0 1 0.2"/>

            <site name="attach_right" pos="0 0 -0.03"/>
        </body>
"""

XML_FOOTER = r"""
    </worldbody>

    <!-- 🌈 Tendones elásticos que unen drones y barra -->
    <tendon>
        <spatial name="tendon_left"
                 limited="true" range="0.01 0.03"
                 springlength="0.1" stiffness="20" damping="3"
                 rgba="0.2 1 0.2 0.5" width="0.005">
            <site site="attach_left"/>
            <site site="bar_left"/>
        </spatial>

        <spatial name="tendon_right"
                 limited="true" range="0.01 0.03"
                 springlength="0.25" stiffness="20" damping="3"
                 rgba="0.2 1 0.2 0.5" width="0.005">
            <site site="attach_right"/>
            <site site="bar_right"/>
        </spatial>
    </tendon>

    <actuator>
        <!-- actuadores del primer dron -->
        <motor site="motor0_1" ctrlrange="0 2" gear="0  0. 1. 0. 0. -0.1"/>
        <motor site="motor1_1" ctrlrange="0 2" gear="0  0. 1. 0. 0.  0.1"/>
        <motor site="motor2_1" ctrlrange="0 2" gear="0  0. 1. 0. 0. -0.1"/>
        <motor site="motor3_1" ctrlrange="0 2" gear="0  0. 1. 0. 0.  0.1"/>

        <!-- actuadores del segundo dron -->
        <motor site="motor0_2" ctrlrange="0 2" gear="0  0. 1. 0. 0. -0.1"/>
        <motor site="motor1_2" ctrlrange="0 2" gear="0  0. 1. 0. 0.  0.1"/>
        <motor site="motor2_2" ctrlrange="0 2" gear="0  0. 1. 0. 0. -0.1"/>
        <motor site="motor3_2" ctrlrange="0 2" gear="0  0. 1. 0. 0.  0.1"/>
    </actuator>

    <sensor>
        <!-- Primer dron -->
        <framepos  name="pos_core_1"  objtype="body" objname="core_1"/>
        <framequat name="quat_core_1" objtype="body" objname="core_1"/>

        <!-- Segundo dron -->
        <framepos  name="pos_core_2"  objtype="body" objname="core_2"/>
        <framequat name="quat_core_2" objtype="body" objname="core_2"/>
    </sensor>

</mujoco>
"""




def generar_barra(num_segmentos=5, longitud_total=1.0, damping=0.0005, stiffness=0.001, mass=0.2) -> str:
    longitud_seg = longitud_total / num_segmentos
    xml = []
    xml.append(f'        <!-- 🔗 Barra flexible con {num_segmentos} segmentos articulados -->')
    xml.append(f'        <body name="bar_seg1" pos="-0.500 0 0.1">')
    xml.append(f'            <joint name="bar_free" type="free" damping="{damping:.3f}" stiffness="{stiffness:.3f}"/>')
    xml.append(f'            <geom type="capsule" fromto="0 0 0 {longitud_seg:.3f} 0 0" size="0.005" rgba="0.3 0.9 0.3 1" mass="{mass/num_segmentos:.3f}"/>')
    xml.append(f'            <site name="bar_left" pos="0 0 0"/>')

    # Crear segmentos internos
    for i in range(2, num_segmentos + 1):
        color_g = 0.9 - (i * 0.1)
        color_b = 0.3 + (i * 0.1)
        xml.append(f'            <body name="bar_seg{i}" pos="{longitud_seg:.3f} 0 0">')
        xml.append(f'                <joint type="hinge" axis="0 1 1" range="-180 180" damping="0.0005" stiffness="0.1" armature="0" limited="false"/>')
        xml.append(f'                <geom type="capsule" fromto="0 0 0 {longitud_seg:.3f} 0 0" size="0.005" rgba="0.3 {color_g:.2f} {color_b:.2f} 1" mass="{mass/num_segmentos:.3f}"/>')

    # sitio final (último segmento)
    xml.append(f'                <site name="bar_right" pos="{longitud_seg:.3f} 0 0"/>')

    # 🔴 Cierre correcto: cerrar SOLO los cuerpos abiertos
    xml.extend(["            </body>" for _ in range(num_segmentos - 1)])  # antes: num_segmentos
    xml.append("        </body>")  # cerrar bar_seg1

    return "\n".join(xml)



def get_xml(num_segmentos=5, longitud_total=1.0) -> str:
    barra_xml = generar_barra(num_segmentos, longitud_total, damping=0.05, stiffness=0.1, mass=0.1)
    XML = XML_HEADER + XML_DRONES + barra_xml + XML_FOOTER
    return XML


# if __name__ == "__main__":
#     xml = get_xml(num_segmentos=6, longitud_total=1.2)
#     print(xml)  # para ver el inicio del XML

if __name__ == "__main__":
    # Parámetros de la barra
    num_segmentos = 6
    longitud_total = 1.2

    # Generar XML
    xml = get_xml(num_segmentos=num_segmentos, longitud_total=longitud_total)

    # Nombre del archivo de salida
    nombre_archivo = "model_based/system/quadrotors_with_flexrod.xml"

    # Guardar en archivo
    with open(nombre_archivo, "w", encoding="utf-8") as f:
        f.write(xml)

    print(f"✅ Archivo XML generado correctamente: {nombre_archivo}")


